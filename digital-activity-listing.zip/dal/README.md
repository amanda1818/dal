# Digital Activity Listing — MVP

A working scaffold of the tool specified in `PRD_Digital_Activity_Listing.md`. It runs
end to end on synthetic data (including a cyclical accounting month-end peak), so you can
open it in IntelliJ/PyCharm, run it, and see real manload numbers, a load profile, VA/NVA
splits, and validity flags before you write a line of new code.

**Core principle (unchanged):** measure the measurable, sample the judgmental, compute the
analytics — metadata only, never keystrokes/screenshots/content.

---

## 1. Quick start (≈3 minutes)

```bash
# from the project root
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python -m scripts.init_db          # create tables + seed catalog + demo study
python -m scripts.run_pipeline     # classify + compute manload (prints a table)

streamlit run dashboard/app.py     # the consultant dashboard  → http://localhost:8501
uvicorn api.main:app --reload      # the ingestion/results API → http://127.0.0.1:8000/docs
python -m reports.generate         # writes study_report.docx
```

A pre-seeded `dal.db` is included, so you can run the dashboard immediately. Re-run
`init_db` to regenerate fresh demo data.

No API key is needed to run. To enable the AI classification pass, copy `.env.example`
to `.env` and set `ANTHROPIC_API_KEY` (the engine works rules-only without it).

---

## 2. What the demo shows

The synthetic study is a Finance department over one full month with three roles
(Finance Manager, Senior Accountant, Staff Accountant). The accountant roles are
**cyclical** — the last 5 business days are a month-end close with more processing,
rework, and waiting. Expected result:

- Overall required ≈ actual headcount.
- **Baseline (mid-month)** required < actual → slack off-peak.
- **Peak (month-end)** required > actual → short ~0.3–0.5 of a head per role.

That baseline-vs-peak gap is the cyclical insight a flat headcount number would hide.

---

## 3. Project layout

```
config.py              # settings (DB URL, thresholds, optional API key)
db/database.py         # SQLAlchemy engine + session
db/models.py           # all tables (PRD §5)
seed/catalog_seed.py   # the activity catalog (PRD Appendix A)
seed/synthetic.py      # demo data generator with month-end peak
engine/classify.py     # rules + optional Claude classification, ESM override, divergence
engine/manload.py      # manload + load profile + baseline/peak
engine/validity.py     # divergences, review queue, peer outliers (PRD Module G)
api/main.py            # FastAPI ingestion + results + retention endpoints
dashboard/app.py       # Streamlit consultant dashboard
reports/generate.py    # Word study report (PRD Module E)
connectors/graph.py    # Microsoft 365 connector — INTERFACE STUB
connectors/gworkspace.py # Google Workspace connector — INTERFACE STUB
agent/agent.py         # desktop capture agent — SKELETON
scripts/init_db.py     # one-shot setup
scripts/run_pipeline.py# classify + manload from the CLI
```

---

## 4. Status — what is DONE vs. STUB vs. TODO

### ✅ Built and working (tested end to end)
- Full data model, all PRD §5 tables (SQLite locally; swap to Postgres via `DATABASE_URL`).
- Activity catalog + seeding.
- Synthetic data generator with a real cyclical month-end peak.
- **Classification engine** — rule matching, ESM-override of blocks, divergence detection;
  optional Claude pass with graceful rules-only fallback.
- **Manload engine** — waste-stripped required headcount, VA/NVA split, data-driven peak
  detection, baseline/peak/overall for cyclical roles, interactive efficiency factor.
- **Validity** — divergence list, review queue, peer-outlier detection.
- **Dashboard** — manload overview, load-profile chart, activity & waste, review & validity,
  standard times, live efficiency slider.
- **API** — `/events`, `/esm`, `/esm/correction`, `/studies/{id}/classify`,
  `/studies/{id}/manload`, `/studies/{id}/standard-times`, participant self-view,
  raw-data deletion (retention).
- **Report** — Word export, aggregated by role only.

### 🟡 Stubbed (interface + TODOs in place; need real credentials/OS to finish)
- `connectors/graph.py` — Microsoft 365 calendar/call/file metadata pull (needs Azure AD app).
- `connectors/gworkspace.py` — Google Workspace pull (needs GCP service account).
- `agent/agent.py` — desktop capture loop (window/idle calls need a real OS + code signing).

### 🔲 Not yet built (next priorities)
- **ESM participant app** — the actual prompt UI (web/PWA or tray). The data path (`/esm`)
  exists; the front end does not.
- **Idle-gap attribution prompt** (PRD §B4) — detect unmatched idle gaps and ask the
  one-tap question on return. The detection hook belongs in the agent + classify.
- **Auth & multi-tenant access control** (PRD §F3) — currently open; add before any real data.
- **Consent flow & retention scheduler** (PRD §F2/F4) — endpoint exists for deletion; the
  scheduled job and consent UI do not.
- **Encryption at rest, audit log, DPA tooling** (PRD §8).
- **ML classifier** (`scikit-learn`) to reduce Claude calls as labelled data accumulates.

---

## 5. What to do next (recommended order)

1. **Switch storage to PostgreSQL** for anything beyond local dev: set `DATABASE_URL`
   and run `init_db`. Models are already Postgres-compatible.
2. **Build the ESM app** (highest value — it's the differentiator). Smallest version:
   a Streamlit/FastAPI web form that posts to `/esm`, fired on a schedule. Then add the
   idle-gap return-prompt.
3. **Implement one telemetry connector** (start with M365 `connectors/graph.py`) so you
   capture real calendar/meeting data with no device install — fill the `NotImplementedError`
   bodies, register an Azure AD app, map results to `/events` rows.
4. **Add auth + consent + retention scheduler** before touching real client data.
5. **Finish the desktop agent** only if clients need deeper desktop signals than telemetry
   gives — then code-sign and package with PyInstaller.
6. **Dogfood on your own office** (PRD Phase 2): point real data at it, calibrate the
   classifier, validate the manload output against what you already know.

Each item maps to a numbered section in the PRD, so hand the PRD + this README to any dev
or AI coding tool and they can continue exactly where this leaves off.

---

## 6. Switching to PostgreSQL

```bash
pip install "psycopg[binary]"
export DATABASE_URL="postgresql+psycopg://user:pass@localhost:5432/dal"
python -m scripts.init_db
```

## 7. Privacy notes baked in
- `window_title_hash` is a hash/category, never raw window text.
- Reporting is role-aggregated; participants are pseudonymous (`pseudonym`, never a real name).
- `DELETE /studies/{id}/raw` removes raw events/ESM/blocks and keeps only aggregates.
- These satisfy the *mechanics* of PRD §8, but the consent flow, encryption-at-rest, and
  scheduled deletion still need to be added before production use.
