"""FastAPI service (PRD Module A ingestion + Module D results + Module F admin).

Run from project root:   uvicorn api.main:app --reload
Then open http://127.0.0.1:8000/docs for an interactive API console.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from db.database import get_session, create_all
from db.models import (
    ActivityEvent, EsmResponse, EsmCorrection, StandardTime, Participant,
    ClassifiedBlock, Study,
)
from engine.classify import classify_study
from engine.manload import compute_manload

app = FastAPI(title="Digital Activity Listing API", version="1.1")


@app.on_event("startup")
def _startup():
    create_all()


# ---------- schemas ----------
class EventIn(BaseModel):
    participant_id: str
    source: str = "agent"
    start_ts: datetime
    end_ts: datetime
    app_name: str = ""
    window_title_hash: str = ""   # NEVER raw window text — hash/category only
    category: str = ""
    is_active: bool = True
    signal_flags: dict = {}


class EsmIn(BaseModel):
    participant_id: str
    prompt_ts: datetime
    response_ts: Optional[datetime] = None
    activity_id: Optional[str] = None
    is_rework: bool = False
    is_waiting: bool = False
    is_new_request: bool = False
    free_note: str = ""


class CorrectionIn(BaseModel):
    participant_id: str
    old_classification: str
    new_classification: str


class StdTimeIn(BaseModel):
    activity_id: str
    std_minutes_per_unit: float
    method: str = "engineered"
    set_by: str = "consultant"


# ---------- ingestion ----------
@app.post("/events")
def post_events(events: list[EventIn], db: Session = Depends(get_session)):
    for e in events:
        db.add(ActivityEvent(**e.model_dump()))
    db.commit()
    return {"ingested": len(events)}


@app.post("/esm")
def post_esm(r: EsmIn, db: Session = Depends(get_session)):
    db.add(EsmResponse(**r.model_dump()))
    db.commit()
    return {"ok": True}


@app.post("/esm/correction")
def post_correction(c: CorrectionIn, db: Session = Depends(get_session)):
    db.add(EsmCorrection(**c.model_dump()))
    db.commit()
    return {"ok": True}


# ---------- pipeline + results ----------
@app.post("/studies/{study_id}/classify")
def run_classify(study_id: str, db: Session = Depends(get_session)):
    if not db.get(Study, study_id):
        raise HTTPException(404, "study not found")
    return classify_study(db, study_id)


@app.get("/studies/{study_id}/manload")
def get_manload(study_id: str, va_efficiency: float = 1.0, db: Session = Depends(get_session)):
    if not db.get(Study, study_id):
        raise HTTPException(404, "study not found")
    return compute_manload(db, study_id, va_efficiency=va_efficiency, persist=False)


@app.post("/studies/{study_id}/standard-times")
def set_std_times(study_id: str, items: list[StdTimeIn], db: Session = Depends(get_session)):
    for it in items:
        db.add(StandardTime(study_id=study_id, **it.model_dump()))
    db.commit()
    return {"set": len(items)}


# ---------- participant self-view (PRD F3) ----------
@app.get("/participants/{participant_id}/data")
def my_data(participant_id: str, db: Session = Depends(get_session)):
    p = db.get(Participant, participant_id)
    if not p:
        raise HTTPException(404, "not found")
    events = db.query(ActivityEvent).filter_by(participant_id=participant_id).count()
    esm = db.query(EsmResponse).filter_by(participant_id=participant_id).count()
    return {"pseudonym": p.pseudonym, "consent_status": p.consent_status,
            "event_count": events, "esm_count": esm}


# ---------- retention / deletion (PRD F4) ----------
@app.delete("/studies/{study_id}/raw")
def delete_raw(study_id: str, db: Session = Depends(get_session)):
    p_ids = [p.id for p in db.query(Participant).filter_by(study_id=study_id).all()]
    if p_ids:
        db.query(ActivityEvent).filter(ActivityEvent.participant_id.in_(p_ids)).delete(synchronize_session=False)
        db.query(EsmResponse).filter(EsmResponse.participant_id.in_(p_ids)).delete(synchronize_session=False)
        db.query(ClassifiedBlock).filter(ClassifiedBlock.participant_id.in_(p_ids)).delete(synchronize_session=False)
    db.commit()
    return {"deleted_raw_for_study": study_id, "aggregates_kept": True}


# ---------- connector stubs (PRD A1) ----------
@app.post("/connectors/graph/sync")
def graph_sync(study_id: str):
    raise HTTPException(501, "Microsoft Graph connector not implemented — see connectors/graph.py")
