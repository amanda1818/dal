"""Desktop capture agent — SKELETON (PRD Module A2).

Captures active app + window title (HASHED, never raw), active-vs-idle, and posts
metadata batches to the API. The cross-platform window/idle calls need to run on a
real Windows/macOS machine and the package must be code-signed before deployment,
so treat this as the starting skeleton, not a finished agent.

Local test idea (Linux/dev): the loop and buffering work; the platform window
calls are guarded so import won't crash. On Windows install:  pip install psutil pywin32 requests

Privacy rules enforced here:
  - window titles are HASHED (sha256, truncated) — raw text never leaves the device
  - tray pause + auto-stop at study end_date should wrap this loop (TODO in deploy)
"""
import time
import hashlib
import platform
from datetime import datetime

API_URL = "http://127.0.0.1:8000/events"
PARTICIPANT_ID = "REPLACE_WITH_PARTICIPANT_ID"
SAMPLE_SECONDS = 30
IDLE_THRESHOLD_SECONDS = 600


def _hash_title(title: str) -> str:
    return hashlib.sha256((title or "").encode()).hexdigest()[:16]


def active_window():
    """Return (app_name, window_title). Platform-specific; safe fallback otherwise."""
    sysname = platform.system()
    try:
        if sysname == "Windows":
            import win32gui, win32process, psutil  # noqa
            hwnd = win32gui.GetForegroundWindow()
            title = win32gui.GetWindowText(hwnd)
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            app = psutil.Process(pid).name()
            return app, title
        elif sysname == "Darwin":
            # macOS: use AppKit via pyobjc (TODO: implement NSWorkspace.frontmostApplication)
            return "unknown", ""
        else:
            return "unknown", ""  # dev/Linux fallback
    except Exception:
        return "unknown", ""


def idle_seconds() -> float:
    """Seconds since last input. TODO: implement per-OS (GetLastInputInfo on Windows)."""
    return 0.0


def run():
    import requests  # imported here so the file is inspectable without requests installed
    buffer = []
    last_app, block_start = None, datetime.utcnow()
    while True:
        app, title = active_window()
        is_active = idle_seconds() < IDLE_THRESHOLD_SECONDS
        if app != last_app and last_app is not None:
            now = datetime.utcnow()
            buffer.append({
                "participant_id": PARTICIPANT_ID, "source": "agent",
                "start_ts": block_start.isoformat(), "end_ts": now.isoformat(),
                "app_name": last_app, "window_title_hash": _hash_title(title),
                "category": "idle" if not is_active else "work", "is_active": is_active,
                "signal_flags": {},
            })
            block_start = now
        last_app = app
        if len(buffer) >= 10:
            try:
                requests.post(API_URL, json=buffer, timeout=5)
                buffer.clear()
            except Exception:
                pass  # retry next cycle
        time.sleep(SAMPLE_SECONDS)


if __name__ == "__main__":
    print("Agent skeleton. Set PARTICIPANT_ID and implement active_window()/idle_seconds() "
          "for your OS before deploying. This will run a capture loop when complete.")
